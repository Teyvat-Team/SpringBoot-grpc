package com.localserver.mysql.service;

import com.localserver.mysql.model.po.DataModel;

public interface IDataModelService {
    public void insertDataModel(DataModel dataModel);
}
